from setuptools import setup, find_packages

setup(
    name='budgetplanner',
    version='0.1',
    packages=find_packages(exclude=['test*']),
    license='MIT',
    description='When piggy bank becomes your financial assisstant',
	url='https://github.com/Saisree-123/DATA533-LAB4',
    author='Saisree GR',
    author_email='saisree.gr@gmail.com'
)
